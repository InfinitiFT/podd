<?php
include('../webservices/function.php');


function user_authenticate($email, $password) {
	$adminQuery = mysql_fetch_assoc(mysql_query("SELECT * FROM qv_admin WHERE email = '".$email."' AND password = '".md5($password)."'"));
	return $adminQuery;
}

function validate_session_admin($uid) {
	if(!isset($uid)) {
	   header("Location: index.php");
	}
}
function blockPractitioner($id){
	$block=mysql_query("UPDATE qv_practitioner SET status=1 WHERE id=".$id."");
	$email = mysql_fetch_assoc(mysql_query("SELECT email FROM qv_practitioner WHERE id=".$id.""));
	$message = '<html>
<head>
<meta name=Title content="">
<meta name=Keywords content="">
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=Generator content="Microsoft Word 14 (filtered)">
<style><!--
 /* Font Definitions */
@font-face
	{font-family:"Courier New";
	panose-1:2 7 3 9 2 2 5 2 4 4;}
@font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Helvetica Neue";
	panose-1:2 0 5 3 0 0 0 2 0 4;}
@font-face
	{font-family:"Helvetica Neue Light";
	panose-1:2 0 4 3 0 0 0 2 0 4;}
 /* Style Definitions */
p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:9.0pt;
	font-family:Verdana;}
h1
	{margin-top:45.0pt;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:0cm;
	font-size:30.0pt;
	font-family:Verdana;
	color:#435169;}
h2
	{margin-top:16.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:14.0pt;
	font-family:Verdana;
	color:#435169;}
h3
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:11.0pt;
	font-family:Verdana;
	color:#435169;}
p.MsoDate, li.MsoDate, div.MsoDate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
a:link, span.MsoHyperlink
	{color:blue;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{color:purple;
	text-decoration:underline;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Tahoma;}
span.Heading1Char
	{font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.Text, li.Text, div.Text
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.Volume, li.Volume, div.Volume
	{margin:0cm;
	margin-bottom:.0001pt;
	text-align:right;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
p.Subhead, li.Subhead, div.Subhead
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.CompanyInfo, li.CompanyInfo, div.CompanyInfo
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:12.25pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-weight:bold;}
p.Quotation2Numbered, li.Quotation2Numbered, div.Quotation2Numbered
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:6.0pt;
	margin-left:32.4pt;
	text-indent:-21.6pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
span.Quotation2NumberedChar
	{font-family:Verdana;
	color:#506280;
	font-style:italic;}
p.TableText, li.TableText, div.TableText
	{margin:0cm;
	margin-bottom:.0001pt;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.StyleQuotationLeft0, li.StyleQuotationLeft0, div.StyleQuotationLeft0
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
.MsoChpDefault
	{font-size:10.0pt;}
 /* Page Definitions */
@page WordSection1
	{size:612.0pt 792.0pt;
	margin:36.0pt 36.0pt 36.7pt 36.0pt;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
--></style>
</head>
<body bgcolor="#07BEC0" lang=EN-GB link=blue vlink=purple>
<div class=WordSection1>
<div align=center>
<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style="border-collapse:collapse">
<tr style="height:2.55pt">
<td width=146 style="width:145.8pt;border:solid #435169 1.0pt;background:
  #CED5E0;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:2.55pt">
<p class=MsoNormal><span lang=EN-US><img width=84 height=75 id="Picture 9" src="Qova%20email%20Template%203_files/image003.gif" alt="Description: Qova logo-22"></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border:solid #435169 1.0pt;
  border-left:none;background:#CED5E0;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:2.55pt">
<h1><span lang=EN-US style="font-size:28.0pt;color:windowtext">Temp Staff
On-Demand</span></h1>
</td>
</tr>
<tr style="height:14.4pt">
<td width=146 style="width:145.8pt;border-top:none;border-left:solid #435169 1.0pt;
  border-bottom:solid #435169 1.0pt;border-right:none;background:#FFCC99;
  padding:1.45pt 3.6pt 1.45pt 5.75pt;height:14.4pt">
<p class=MsoDate><span lang=EN-US>&nbsp;</span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border-top:none;border-left:
  none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  background:#FFCC99;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:14.4pt">
<p class=Volume><span lang=EN-US>&nbsp;</span></p>
</td>
</tr>
<tr style="height:566.65pt">
<td width=146 valign=top style="width:145.8pt;border:solid #435169 1.0pt;
  border-top:none;background:#EAEDF2;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:566.65pt">
<div align=center>
<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=114 style="border-collapse:collapse;border:none">
<tr>
<td width=114 valign=top style="width:114.15pt;padding:144.0pt 5.75pt 0cm 5.75pt">
<p class=StyleQuotationLeft0><b><span lang=EN-US style="font-size:12.0pt">3
Steps to Request Qova:</span></b></p>
</td>
</tr>
</table>
</div>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;text-autospace:
  none"><b><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue"">Use
the iPhone or Android app to request Qova.</span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;text-autospace:
  none"><b><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue"">1.
View and choose your Practitioner from the list.</span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;text-autospace:
  none"><b><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue"">&nbsp;</span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;text-autospace:
  none"><b><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue"">2.
Sit back and relax and watch the practitioner make their way to you.</span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;text-autospace:
  none"><b><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue"">&nbsp;</span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;text-autospace:
  none"><b><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue"">3.
After job is completed, we will charge your credit card on file and email you a
receipt.</span></b></p>
<p class=Quotation2Numbered style="margin-left:10.8pt;text-indent:0cm"><span lang=EN-US>&nbsp;</span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border-top:none;border-left:
  none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  padding:1.45pt 18.7pt 1.45pt 12.95pt;height:566.65pt">
<h2><span lang=EN-US style="font-size:22.0pt;color:windowtext">Qova - UnBlocked User<o:p></o:p></span></h2>
<h2><span lang=EN-US style="mso-bidi-font-size:14.0pt;font-family:Helvetica;
  mso-bidi-font-family:"Helvetica Neue Light";color:windowtext">Admin Un-blocked your account after verification.</span><span lang=EN-US style="mso-bidi-font-size:14.0pt;
  font-family:Helvetica;color:windowtext"><o:p></o:p></span></h2>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt">_ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ <o:p></o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt">&nbsp;</span></p>
<p class=MsoNormal style="text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue"">Dear Member, </span></p>
<p class=MsoNormal style="text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue"">&nbsp;</span></p>
<p class=MsoNormal style="text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue">You have been UnBlocked by Admin User. Your account has been verified and now you can enjoy the services.</span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:10.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626">Contact
Us</span></b><span lang=EN-US style="font-size:14.0pt;font-family:"Helvetica Neue Light";
  mso-bidi-font-family:"Helvetica Neue Light";color:#262626"><o:p></o:p></span></p>
<p class=Text><span lang=EN-US style="font-size:10.0pt;line-height:120%;
  font-family:"Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";
  color:#262626">We are here to answer any questions you may have and make sure
you have a pleasant Qova experience. To get in touch, just head to
support@qova.co.uk</span></p>
</td>
<td style="mso-cell-special:placeholder;border:none;padding:0cm 0cm 0cm 0cm" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
</table>
</div>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</div>
</body>
</html>';
    $subject = 'Qova - UnBlocked User';
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= 'From: <website@qova.com>' . "\r\n";
    mail($email['email'], $subject, $message, $headers);
	return 1;
}

function unBlockPractitioner($id){
	$unBlock=mysql_query("UPDATE qv_practitioner SET status = 0 WHERE id=".$id."");
	$email = mysql_fetch_assoc(mysql_query("SELECT email FROM qv_practitioner WHERE id=".$id.""));
	$message = '<html>
<html>
<head>
<meta name=Title content="">
<meta name=Keywords content="">
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=Generator content="Microsoft Word 14 (filtered)">
<style><!--
 /* Font Definitions */
@font-face
	{font-family:"Courier New";
	panose-1:2 7 3 9 2 2 5 2 4 4;}
@font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Helvetica Neue";
	panose-1:2 0 5 3 0 0 0 2 0 4;}
@font-face
	{font-family:"Helvetica Neue Light";
	panose-1:2 0 4 3 0 0 0 2 0 4;}
 /* Style Definitions */
p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:9.0pt;
	font-family:Verdana;}
h1
	{margin-top:45.0pt;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:0cm;
	font-size:30.0pt;
	font-family:Verdana;
	color:#435169;}
h2
	{margin-top:16.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:14.0pt;
	font-family:Verdana;
	color:#435169;}
h3
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:11.0pt;
	font-family:Verdana;
	color:#435169;}
p.MsoDate, li.MsoDate, div.MsoDate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
a:link, span.MsoHyperlink
	{color:blue;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{color:purple;
	text-decoration:underline;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Tahoma;}
span.Heading1Char
	{font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.Text, li.Text, div.Text
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.Volume, li.Volume, div.Volume
	{margin:0cm;
	margin-bottom:.0001pt;
	text-align:right;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
p.Subhead, li.Subhead, div.Subhead
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.CompanyInfo, li.CompanyInfo, div.CompanyInfo
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:12.25pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-weight:bold;}
p.Quotation2Numbered, li.Quotation2Numbered, div.Quotation2Numbered
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:6.0pt;
	margin-left:32.4pt;
	text-indent:-21.6pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
span.Quotation2NumberedChar
	{font-family:Verdana;
	color:#506280;
	font-style:italic;}
p.TableText, li.TableText, div.TableText
	{margin:0cm;
	margin-bottom:.0001pt;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.StyleQuotationLeft0, li.StyleQuotationLeft0, div.StyleQuotationLeft0
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
.MsoChpDefault
	{font-size:10.0pt;}
 /* Page Definitions */
@page WordSection1
	{size:612.0pt 792.0pt;
	margin:36.0pt 36.0pt 36.7pt 36.0pt;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
--></style>
</head>
<body bgcolor="#07BEC0" lang=EN-GB link=blue vlink=purple style="tab-interval:
36.0pt">
<div class=WordSection1>
<div align=center>
<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style="border-collapse:collapse;mso-table-layout-alt:fixed;mso-yfti-tbllook:
 480;mso-padding-alt:1.45pt 18.7pt 1.45pt 12.95pt">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;height:2.55pt;mso-row-margin-right:
  .55pt">
<td width=146 style="width:145.8pt;border:solid #435169 1.0pt;mso-border-alt:
  solid #435169 .5pt;mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;
  padding:1.45pt 18.7pt 1.45pt 12.95pt;height:2.55pt">
<p class=MsoNormal><span lang=EN-US style="mso-no-proof:yes"><!--[if gte vml 1]><v:shapetype
   id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t"
   path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="Picture_x0020_9" o:spid="_x0000_i1025" type="#_x0000_t75"
   alt="Description: Qova logo-22" style="width:82pt;height:73pt;visibility:visible;
   mso-wrap-style:square">
   <v:imagedata src="Qova%20email%20Template_files/image003.png" o:title="Qova logo-22"/>
  </v:shape><![endif]--><![if !vml]><img width=84 height=75 src="Qova%20email%20Template_files/image004.gif" alt="Description: Qova logo-22" v:shapes="Picture_x0020_9"><![endif]></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border:solid #435169 1.0pt;
  border-left:none;mso-border-left-alt:solid #435169 .5pt;mso-border-alt:solid #435169 .5pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:2.55pt">
<h1><span lang=EN-US style="font-size:28.0pt;color:windowtext">Temp Staff
On-Demand<span style="mso-no-proof:yes"><o:p></o:p></span></span></h1>
</td>
<td style="mso-cell-special:placeholder;border:none;border-bottom:solid #435169 1.0pt" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
<tr style="mso-yfti-irow:1;height:14.4pt">
<td width=146 style="width:145.8pt;border-top:none;border-left:solid #435169 1.0pt;
  border-bottom:solid #435169 1.0pt;border-right:none;mso-border-top-alt:solid #435169 .25pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#FFCC99;padding:1.45pt 3.6pt 1.45pt 5.75pt;
  height:14.4pt">
<p class=MsoDate><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=419 colspan=2 valign=top style="width:418.5pt;border-top:none;
  border-left:none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-top-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;mso-border-right-alt:solid #435169 .25pt;
  background:#FFCC99;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:14.4pt">
<p class=Volume><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
</tr>
<tr style="mso-yfti-irow:2;mso-yfti-lastrow:yes;height:566.65pt;mso-row-margin-right:
  .55pt">
<td width=146 valign=top style="width:145.8pt;border:solid #435169 1.0pt;
  border-top:none;mso-border-top-alt:solid #435169 .25pt;mso-border-alt:solid #435169 .25pt;
  background:#EAEDF2;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:566.65pt">
<div align=center>
<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=114 style="border-collapse:collapse;mso-table-layout-alt:fixed;border:none;
   mso-yfti-tbllook:480;mso-padding-alt:3.6pt 5.75pt 0cm 5.75pt;mso-border-insideh:
   none;mso-border-insidev:none">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes">
<td width=114 valign=top style="width:114.15pt;padding:144.0pt 5.75pt 0cm 5.75pt">
<p class=StyleQuotationLeft0><b style="mso-bidi-font-weight:normal"><span lang=EN-US style="font-size:12.0pt">3 Steps to Request Qova:<o:p></o:p></span></b></p>
</td>
</tr>
</table>
</div>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">Use the iPhone or Android app to
request Qova.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">1. View and choose your Practitioner
from the list.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">2. Sit back and relax and watch the
practitioner make their way to you.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">3. After job is completed, we will
charge your credit card on file and email you a receipt.</span></b><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue";mso-bidi-font-family:
  "Helvetica Neue""><o:p></o:p></span></p>
<p class=Quotation2Numbered style="margin-left:10.8pt;text-indent:0cm;
  mso-list:none;tab-stops:36.0pt"><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border-top:none;border-left:
  none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-alt:solid #435169 .25pt;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:566.65pt">
<h2><span lang=EN-US style="font-size:22.0pt;color:windowtext">Qova - Blocked User<o:p></o:p></span></h2>
<h2><span lang=EN-US style="mso-bidi-font-size:14.0pt;font-family:Helvetica;
  mso-bidi-font-family:"Helvetica Neue Light";color:windowtext">Admin Blocked your account.</span><span lang=EN-US style="mso-bidi-font-size:14.0pt;
  font-family:Helvetica;color:windowtext"><o:p></o:p></span></h2>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt">_ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ <o:p></o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt"><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">Dear Member, <o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">You have been Blocked by Admin User. Once your account will be verified your account will be unblocked. After that you can enjoy the services. <o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:10.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626">Contact
Us</span></b><span lang=EN-US style="font-size:14.0pt;font-family:"Helvetica Neue Light";
  mso-bidi-font-family:"Helvetica Neue Light";color:#262626"><o:p></o:p></span></p>
<p class=Text><span lang=EN-US style="font-size:10.0pt;line-height:120%;
  font-family:"Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";
  color:#262626">We are here to answer any questions you may have and make sure
you have a pleasant Qova experience. To get in touch, just head to
support@qova.co.uk</span></p>
</td>
<td style="mso-cell-special:placeholder;border:none;padding:0cm 0cm 0cm 0cm" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
</table>
</div>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</div>
</body>
</html>
';
    $subject = 'Qova - Blocked User';
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= 'From: <website@qova.com>' . "\r\n";
    mail($email['email'], $subject, $message, $headers);
	return 0;
}
function blockCompany($id){
	$block=mysql_query("UPDATE qv_company SET status=1 WHERE id=".$id."");
	$email = mysql_fetch_assoc(mysql_query("SELECT email FROM qv_company WHERE id=".$id.""));
		$message = '<html>
<head>
<meta name=Title content="">
<meta name=Keywords content="">
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=Generator content="Microsoft Word 14 (filtered)">
<style><!--
 /* Font Definitions */
@font-face
	{font-family:"Courier New";
	panose-1:2 7 3 9 2 2 5 2 4 4;}
@font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Helvetica Neue";
	panose-1:2 0 5 3 0 0 0 2 0 4;}
@font-face
	{font-family:"Helvetica Neue Light";
	panose-1:2 0 4 3 0 0 0 2 0 4;}
 /* Style Definitions */
p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:9.0pt;
	font-family:Verdana;}
h1
	{margin-top:45.0pt;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:0cm;
	font-size:30.0pt;
	font-family:Verdana;
	color:#435169;}
h2
	{margin-top:16.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:14.0pt;
	font-family:Verdana;
	color:#435169;}
h3
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:11.0pt;
	font-family:Verdana;
	color:#435169;}
p.MsoDate, li.MsoDate, div.MsoDate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
a:link, span.MsoHyperlink
	{color:blue;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{color:purple;
	text-decoration:underline;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Tahoma;}
span.Heading1Char
	{font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.Text, li.Text, div.Text
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.Volume, li.Volume, div.Volume
	{margin:0cm;
	margin-bottom:.0001pt;
	text-align:right;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
p.Subhead, li.Subhead, div.Subhead
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.CompanyInfo, li.CompanyInfo, div.CompanyInfo
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:12.25pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-weight:bold;}
p.Quotation2Numbered, li.Quotation2Numbered, div.Quotation2Numbered
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:6.0pt;
	margin-left:32.4pt;
	text-indent:-21.6pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
span.Quotation2NumberedChar
	{font-family:Verdana;
	color:#506280;
	font-style:italic;}
p.TableText, li.TableText, div.TableText
	{margin:0cm;
	margin-bottom:.0001pt;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.StyleQuotationLeft0, li.StyleQuotationLeft0, div.StyleQuotationLeft0
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
.MsoChpDefault
	{font-size:10.0pt;}
 /* Page Definitions */
@page WordSection1
	{size:612.0pt 792.0pt;
	margin:36.0pt 36.0pt 36.7pt 36.0pt;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
--></style>
</head>
<body bgcolor="#07BEC0" lang=EN-GB link=blue vlink=purple style="tab-interval:
36.0pt">
<div class=WordSection1>
<div align=center>
<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style="border-collapse:collapse;mso-table-layout-alt:fixed;mso-yfti-tbllook:
 480;mso-padding-alt:1.45pt 18.7pt 1.45pt 12.95pt">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;height:2.55pt;mso-row-margin-right:
  .55pt">
<td width=146 style="width:145.8pt;border:solid #435169 1.0pt;mso-border-alt:
  solid #435169 .5pt;mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;
  padding:1.45pt 18.7pt 1.45pt 12.95pt;height:2.55pt">
<p class=MsoNormal><span lang=EN-US style="mso-no-proof:yes"><!--[if gte vml 1]><v:shapetype
   id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t"
   path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="Picture_x0020_9" o:spid="_x0000_i1025" type="#_x0000_t75"
   alt="Description: Qova logo-22" style="width:82pt;height:73pt;visibility:visible;
   mso-wrap-style:square">
   <v:imagedata src="Qova%20email%20Template_files/image003.png" o:title="Qova logo-22"/>
  </v:shape><![endif]--><![if !vml]><img width=84 height=75 src="Qova%20email%20Template_files/image004.gif" alt="Description: Qova logo-22" v:shapes="Picture_x0020_9"><![endif]></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border:solid #435169 1.0pt;
  border-left:none;mso-border-left-alt:solid #435169 .5pt;mso-border-alt:solid #435169 .5pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:2.55pt">
<h1><span lang=EN-US style="font-size:28.0pt;color:windowtext">Temp Staff
On-Demand<span style="mso-no-proof:yes"><o:p></o:p></span></span></h1>
</td>
<td style="mso-cell-special:placeholder;border:none;border-bottom:solid #435169 1.0pt" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
<tr style="mso-yfti-irow:1;height:14.4pt">
<td width=146 style="width:145.8pt;border-top:none;border-left:solid #435169 1.0pt;
  border-bottom:solid #435169 1.0pt;border-right:none;mso-border-top-alt:solid #435169 .25pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#FFCC99;padding:1.45pt 3.6pt 1.45pt 5.75pt;
  height:14.4pt">
<p class=MsoDate><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=419 colspan=2 valign=top style="width:418.5pt;border-top:none;
  border-left:none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-top-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;mso-border-right-alt:solid #435169 .25pt;
  background:#FFCC99;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:14.4pt">
<p class=Volume><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
</tr>
<tr style="mso-yfti-irow:2;mso-yfti-lastrow:yes;height:566.65pt;mso-row-margin-right:
  .55pt">
<td width=146 valign=top style="width:145.8pt;border:solid #435169 1.0pt;
  border-top:none;mso-border-top-alt:solid #435169 .25pt;mso-border-alt:solid #435169 .25pt;
  background:#EAEDF2;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:566.65pt">
<div align=center>
<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=114 style="border-collapse:collapse;mso-table-layout-alt:fixed;border:none;
   mso-yfti-tbllook:480;mso-padding-alt:3.6pt 5.75pt 0cm 5.75pt;mso-border-insideh:
   none;mso-border-insidev:none">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes">
<td width=114 valign=top style="width:114.15pt;padding:144.0pt 5.75pt 0cm 5.75pt">
<p class=StyleQuotationLeft0><b style="mso-bidi-font-weight:normal"><span lang=EN-US style="font-size:12.0pt">3 Steps to Request Qova:<o:p></o:p></span></b></p>
</td>
</tr>
</table>
</div>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">Use the iPhone or Android app to
request Qova.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">1. View and choose your Practitioner
from the list.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">2. Sit back and relax and watch the
practitioner make their way to you.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">3. After job is completed, we will
charge your credit card on file and email you a receipt.</span></b><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue";mso-bidi-font-family:
  "Helvetica Neue""><o:p></o:p></span></p>
<p class=Quotation2Numbered style="margin-left:10.8pt;text-indent:0cm;
  mso-list:none;tab-stops:36.0pt"><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border-top:none;border-left:
  none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-alt:solid #435169 .25pt;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:566.65pt">
<h2><span lang=EN-US style="font-size:22.0pt;color:windowtext">Qova - UnBlocked User<o:p></o:p></span></h2>
<h2><span lang=EN-US style="mso-bidi-font-size:14.0pt;font-family:Helvetica;
  mso-bidi-font-family:"Helvetica Neue Light";color:windowtext">Admin Un-blocked your account after verification.</span><span lang=EN-US style="mso-bidi-font-size:14.0pt;
  font-family:Helvetica;color:windowtext"><o:p></o:p></span></h2>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt">_ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ <o:p></o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt"><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">Dear Member, <o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">You have been UnBlocked by Admin User. Your account has been verified and now you can enjoy the services. <o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:10.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626">Contact
Us</span></b><span lang=EN-US style="font-size:14.0pt;font-family:"Helvetica Neue Light";
  mso-bidi-font-family:"Helvetica Neue Light";color:#262626"><o:p></o:p></span></p>
<p class=Text><span lang=EN-US style="font-size:10.0pt;line-height:120%;
  font-family:"Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";
  color:#262626">We are here to answer any questions you may have and make sure
you have a pleasant Qova experience. To get in touch, just head to
support@qova.co.uk</span></p>
</td>
<td style="mso-cell-special:placeholder;border:none;padding:0cm 0cm 0cm 0cm" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
</table>
</div>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</div>
</body>
</html>
';
    $subject = 'Qova - UnBlocked User';
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= 'From: <support@qova.co.uk>' . "\r\n";
   // $subject = 'Qova - UnBlocked Company';
    mail($email['email'], $subject, $message, $headers);
	return 1;
}

function unBlockCompany($id){
	$unBlock=mysql_query("UPDATE qv_company SET status=0 WHERE id=".$id."");
	$email = mysql_fetch_assoc(mysql_query("SELECT email FROM qv_company WHERE id=".$id.""));
$message = '<html>
<head>
<meta name=Title content="">
<meta name=Keywords content="">
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=Generator content="Microsoft Word 14 (filtered)">
<style><!--
 /* Font Definitions */
@font-face
	{font-family:"Courier New";
	panose-1:2 7 3 9 2 2 5 2 4 4;}
@font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Helvetica Neue";
	panose-1:2 0 5 3 0 0 0 2 0 4;}
@font-face
	{font-family:"Helvetica Neue Light";
	panose-1:2 0 4 3 0 0 0 2 0 4;}
 /* Style Definitions */
p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:9.0pt;
	font-family:Verdana;}
h1
	{margin-top:45.0pt;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:0cm;
	font-size:30.0pt;
	font-family:Verdana;
	color:#435169;}
h2
	{margin-top:16.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:14.0pt;
	font-family:Verdana;
	color:#435169;}
h3
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:11.0pt;
	font-family:Verdana;
	color:#435169;}
p.MsoDate, li.MsoDate, div.MsoDate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
a:link, span.MsoHyperlink
	{color:blue;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{color:purple;
	text-decoration:underline;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Tahoma;}
span.Heading1Char
	{font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.Text, li.Text, div.Text
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.Volume, li.Volume, div.Volume
	{margin:0cm;
	margin-bottom:.0001pt;
	text-align:right;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
p.Subhead, li.Subhead, div.Subhead
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.CompanyInfo, li.CompanyInfo, div.CompanyInfo
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:12.25pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-weight:bold;}
p.Quotation2Numbered, li.Quotation2Numbered, div.Quotation2Numbered
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:6.0pt;
	margin-left:32.4pt;
	text-indent:-21.6pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
span.Quotation2NumberedChar
	{font-family:Verdana;
	color:#506280;
	font-style:italic;}
p.TableText, li.TableText, div.TableText
	{margin:0cm;
	margin-bottom:.0001pt;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.StyleQuotationLeft0, li.StyleQuotationLeft0, div.StyleQuotationLeft0
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
.MsoChpDefault
	{font-size:10.0pt;}
 /* Page Definitions */
@page WordSection1
	{size:612.0pt 792.0pt;
	margin:36.0pt 36.0pt 36.7pt 36.0pt;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
--></style>
</head>
<body bgcolor="#07BEC0" lang=EN-GB link=blue vlink=purple style="tab-interval:
36.0pt">
<div class=WordSection1>
<div align=center>
<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style="border-collapse:collapse;mso-table-layout-alt:fixed;mso-yfti-tbllook:
 480;mso-padding-alt:1.45pt 18.7pt 1.45pt 12.95pt">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;height:2.55pt;mso-row-margin-right:
  .55pt">
<td width=146 style="width:145.8pt;border:solid #435169 1.0pt;mso-border-alt:
  solid #435169 .5pt;mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;
  padding:1.45pt 18.7pt 1.45pt 12.95pt;height:2.55pt">
<p class=MsoNormal><span lang=EN-US style="mso-no-proof:yes"><!--[if gte vml 1]><v:shapetype
   id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t"
   path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="Picture_x0020_9" o:spid="_x0000_i1025" type="#_x0000_t75"
   alt="Description: Qova logo-22" style="width:82pt;height:73pt;visibility:visible;
   mso-wrap-style:square">
   <v:imagedata src="Qova%20email%20Template_files/image003.png" o:title="Qova logo-22"/>
  </v:shape><![endif]--><![if !vml]><img width=84 height=75 src="Qova%20email%20Template_files/image004.gif" alt="Description: Qova logo-22" v:shapes="Picture_x0020_9"><![endif]></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border:solid #435169 1.0pt;
  border-left:none;mso-border-left-alt:solid #435169 .5pt;mso-border-alt:solid #435169 .5pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:2.55pt">
<h1><span lang=EN-US style="font-size:28.0pt;color:windowtext">Temp Staff
On-Demand<span style="mso-no-proof:yes"><o:p></o:p></span></span></h1>
</td>
<td style="mso-cell-special:placeholder;border:none;border-bottom:solid #435169 1.0pt" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
<tr style="mso-yfti-irow:1;height:14.4pt">
<td width=146 style="width:145.8pt;border-top:none;border-left:solid #435169 1.0pt;
  border-bottom:solid #435169 1.0pt;border-right:none;mso-border-top-alt:solid #435169 .25pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#FFCC99;padding:1.45pt 3.6pt 1.45pt 5.75pt;
  height:14.4pt">
<p class=MsoDate><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=419 colspan=2 valign=top style="width:418.5pt;border-top:none;
  border-left:none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-top-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;mso-border-right-alt:solid #435169 .25pt;
  background:#FFCC99;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:14.4pt">
<p class=Volume><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
</tr>
<tr style="mso-yfti-irow:2;mso-yfti-lastrow:yes;height:566.65pt;mso-row-margin-right:
  .55pt">
<td width=146 valign=top style="width:145.8pt;border:solid #435169 1.0pt;
  border-top:none;mso-border-top-alt:solid #435169 .25pt;mso-border-alt:solid #435169 .25pt;
  background:#EAEDF2;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:566.65pt">
<div align=center>
<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=114 style="border-collapse:collapse;mso-table-layout-alt:fixed;border:none;
   mso-yfti-tbllook:480;mso-padding-alt:3.6pt 5.75pt 0cm 5.75pt;mso-border-insideh:
   none;mso-border-insidev:none">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes">
<td width=114 valign=top style="width:114.15pt;padding:144.0pt 5.75pt 0cm 5.75pt">
<p class=StyleQuotationLeft0><b style="mso-bidi-font-weight:normal"><span lang=EN-US style="font-size:12.0pt">3 Steps to Request Qova:<o:p></o:p></span></b></p>
</td>
</tr>
</table>
</div>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">Use the iPhone or Android app to
request Qova.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">1. View and choose your Practitioner
from the list.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">2. Sit back and relax and watch the
practitioner make their way to you.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">3. After job is completed, we will
charge your credit card on file and email you a receipt.</span></b><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue";mso-bidi-font-family:
  "Helvetica Neue""><o:p></o:p></span></p>
<p class=Quotation2Numbered style="margin-left:10.8pt;text-indent:0cm;
  mso-list:none;tab-stops:36.0pt"><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border-top:none;border-left:
  none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-alt:solid #435169 .25pt;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:566.65pt">
<h2><span lang=EN-US style="font-size:22.0pt;color:windowtext">Qova - Blocked User<o:p></o:p></span></h2>
<h2><span lang=EN-US style="mso-bidi-font-size:14.0pt;font-family:Helvetica;
  mso-bidi-font-family:"Helvetica Neue Light";color:windowtext">Admin Blocked your account.</span><span lang=EN-US style="mso-bidi-font-size:14.0pt;
  font-family:Helvetica;color:windowtext"><o:p></o:p></span></h2>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt">_ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ <o:p></o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt"><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">Dear Member, <o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">You have been Blocked by Admin User. Once your account will be verified your account will be unblocked. After that you can enjoy the services. <o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:10.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626">Contact
Us</span></b><span lang=EN-US style="font-size:14.0pt;font-family:"Helvetica Neue Light";
  mso-bidi-font-family:"Helvetica Neue Light";color:#262626"><o:p></o:p></span></p>
<p class=Text><span lang=EN-US style="font-size:10.0pt;line-height:120%;
  font-family:"Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";
  color:#262626">We are here to answer any questions you may have and make sure
you have a pleasant Qova experience. To get in touch, just head to
support@qova.co.uk</span></p>
</td>
<td style="mso-cell-special:placeholder;border:none;padding:0cm 0cm 0cm 0cm" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
</table>
</div>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</div>
</body>
</html>
';
    $subject = 'Qova - Blocked User';
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= 'From: <support@qova.co.uk>' . "\r\n";
    //$subject = 'Qova - Blocked Company';
    mail($email['email'], $subject, $message, $headers);
	return 0;
}

function validate_email_admin($email) {
	$adminEmail = mysql_fetch_assoc(mysql_query("SELECT email FROM qv_admin WHERE email = '".$email."'"));
	return $adminEmail;
}

function practitioners() {
		$practitionerQry = mysql_query("SELECT * FROM `qv_practitioner` order by`created_date` desc");
		$content = '';
		while($practitioner = mysql_fetch_assoc($practitionerQry)) {
			//$practitioner = getpractitionerInfo($practitionerData['id']);
				
			if($practitioner['status']==0){
				$status = '<button class="btn btn-success" data-toggle="modal" data-target="#blocks" type="button" id="blockpractitioner-'.$practitioner['id'].'">UnBlock</button>';
			}
			else if($practitioner['status']==1){
				$status = '<button class="btn btn-danger" data-toggle="modal" data-target="#blocks" type="button" id="blockpractitioner-'.$practitioner['id'].'">Block</button>';
			}
			if($practitioner['verified']== 1){
				$style = '#ace600';		
			}
			else{
			$style = '#ffffff';	
			}

			$date=date("Y-m-d",$practitioner['created_date']);
			$content .= '<tr bgcolor = "'.$style.'" id="practitionerrow-'.$practitioner['id'].'">
				<td>'.ucfirst($practitioner['firstname']).'</td>
				<td>'.ucfirst($practitioner['lastname']).'</td>
				<td>'.$practitioner['phone_no'].'</td>
				<td>'.$practitioner['zipcode'].'</td>
				<td>'.ucfirst($practitioner['state']).'</td>
				<td>'.getCategoryName($practitioner['category']).'</td>
				<td>'.$date.'</td>
				<td><a class="btn btn-warning view-practitioner" href="practitioner_detail.php?practitionerid='.$practitioner['id'].'">View</a>
				 <a id="edit-brand" class="btn btn-info edit-practitioner" style="margin:0 3px 0 1px;" href="edit_practitioner.php?practitionerid='.$practitioner['id'].'">Edit</a> 
				<button class="btn btn-danger delete-practitioner" data-toggle="modal" data-target="#confirm" type="button" id="deletepractitioner-'.$practitioner['id'].'">Delete</button>
				'.$status.'</td>
			  </tr>';		  
		}
		return $content;
}
function transactionHistory(){
	$captured=mysql_query("SELECT request_id,user_id,practitioner_id,total_cost FROM qv_transactions WHERE status='captured'");
	$content='';
	while($capturedData=mysql_fetch_assoc($captured)){
		$requestdata=mysql_fetch_assoc(mysql_query("SELECT* FROM qv_requests WHERE id=
		'".$capturedData['request_id']."'"));
		$companyID=mysql_fetch_assoc(mysql_query("SELECT id  FROM `qv_users` WHERE role_id=2 and user_id=
		'".$capturedData['user_id']."'"));
		$practionerID=mysql_fetch_assoc(mysql_query("SELECT id  FROM `qv_users` WHERE role_id=3 and user_id=
		'".$capturedData['practitioner_id']."'"));
		$categoryName=getCategoryName($requestdata['category']);
		$practitionerInfo=getpractitionerInfo($practionerID['id']);
		$companyInfo=getcompanyInfo($companyID['id']);
		$datedata=date('Y/m/d',$requestdata['when']);
		$content .= '<tr>
						<td>'.$categoryName.'</td>
						<td>'.ucfirst($companyInfo['name']).'</td>
						<td>'.ucfirst($practitionerInfo['firstname']).' '.ucfirst($practitionerInfo['lastname']).'</td>
						<td>'.$datedata.'</td>
						<td>'.$capturedData['total_cost'].'</td>
						
					  </tr>';		
				}
		return $content;
}
function notTransfered(){
	$captured=mysql_query("SELECT id,request_id,user_id,practitioner_id,sum(total_cost) FROM qv_transactions WHERE transfer_status='0' AND status = 'captured' group by practitioner_id");
	$content='';
	while($capturedData=mysql_fetch_assoc($captured))
	{
		$practionerID=mysql_fetch_assoc(mysql_query("SELECT id FROM `qv_users` WHERE role_id=3 and user_id='".$capturedData['practitioner_id']."'"));
		$practitionerInfo=getpractitionerInfo($practionerID['id']);
		$content .= '<tr>
						<td>'.$practitionerInfo['firstname'].' '.$practitionerInfo['lastname'].'</td>
						<td>'.$capturedData['sum(total_cost)'].'</td>
						<td><a href="transfer_payment.php?practitionerID='.$capturedData['practitioner_id'].'" class="btn btn-primary" id="transferPayment">Transfer</a></td>
					  </tr>';		
	}
	return $content;
}
function getPractitionerID($user_id){
	$sql = mysql_query("SELECT `user_id` FROM `qv_users` WHERE `id` = '".$user_id."' AND role_id = 3");
		$data = array();
		$data = mysql_fetch_assoc($sql);
		return $data['user_id'];
	}
function serviceCost($practitionerID){
	$userID = getPractitionerID($practitionerID);
	$transactionData=mysql_query("SELECT id,request_id,user_id,practitioner_id,total_cost,transfer_status,transfer_date FROM qv_transactions WHERE practitioner_id='".$userID."'");
	$content='';
	while($data=mysql_fetch_assoc($transactionData))
	{
	
		$practionerID=mysql_fetch_assoc(mysql_query("SELECT id  FROM `qv_users` WHERE role_id=3 and user_id=
		'".$data['practitioner_id']."'"));
		$practitionerInfo=getpractitionerInfo($practionerID['id']);
		$companyID=mysql_fetch_assoc(mysql_query("SELECT id  FROM `qv_users` WHERE role_id=2 and user_id=
		'".$data['user_id']."'"));
		$date=date("Y-m-d",$data['transfer_date']);
		$companyInfo=getcompanyInfo($companyID['id']);
		$transfer_status=$data['transfer_status'];
		if($transfer_status==0){
			$btn='btn btn-danger';	
			$btnText='Not Transferd';
		}else{
			$btn='btn btn-primary';	
			$btnText='Transferd';
		}
		$content .= '<tr>
				<td>'.ucfirst($companyInfo['name']).'</td>
				<td>'.ucfirst($practitionerInfo['firstname']).' '.ucfirst($practitionerInfo['lastname']).'</td>
				<td>'.$data['total_cost'].'</td>
				<td>'.$date.'</td>
				<td><button class="'.$btn.'" >'.$btnText.'</button></td>
			  </tr>';		
		}
		return $content;
		
	}

function transfered(){
	$captured=mysql_query("SELECT id,request_id,transfer_date,user_id,practitioner_id,sum(total_cost) FROM qv_transactions WHERE transfer_status='1' AND status = 'captured' group by practitioner_id");
	$content='';
	while($capturedData=mysql_fetch_assoc($captured))
	{
		$practionerID=mysql_fetch_assoc(mysql_query("SELECT id  FROM `qv_users` WHERE role_id=3 and user_id=
		'".$capturedData['practitioner_id']."'"));
		$transferDate=date('Y/m/d',$capturedData['transfer_date']);
		$practitionerInfo=getpractitionerInfo($practionerID['id']);
		$createdDate=date('Y/m/d',$practitionerInfo['created_date']);
		$content .= '<tr>
						<td>'.ucfirst($practitionerInfo['firstname']).' '.ucfirst($practitionerInfo['lastname']).'</td>
						<td>'.$capturedData['sum(total_cost)'].'</td>
						<td>'.$createdDate.'</td>
						<td>'.$transferDate.'</td>
					  </tr>';		
	}
	return $content;
}


function reviews($practitionerID) {
		$userID = getPractitionerUserID($practitionerID);
		$reviewQry = mysql_query("SELECT * FROM qv_ratings WHERE practitioner_id = '".$userID."'");
		$content = '';
		while($reviewData = mysql_fetch_assoc($reviewQry)) {
			$getID = getID($reviewData['company_id']);
			$company = getcompanyInfo($getID['id']);
			$avg = $reviewData['rating']*100/5 ;
		$content .= '<tr id="reviewrow-'.$reviewData['id'].'">
				<td>'.ucfirst($company['name']).'</td>
				<td><div class="rating-container"><div class="rat" style="width:'.$avg.'%;"></div></div></td>
				<td>'.$reviewData['comments'].'</td>
				<td>'.date("d/m/Y", $reviewData['created_date']).'</td>
			  </tr>';		
		}
		return $content;
}

function getCategorySelected($category) {

  $categoryQry = mysql_query("SELECT name FROM qv_category where name!='".$category."'");
  $options .= '<option selected>'.$category.'</option>';
  while($categoryData = mysql_fetch_assoc($categoryQry)) {
				$options .= '<option>'.$categoryData['name'].'</option>';
  }  
  return $options;
}


function getCategories() {
  $categoryQry = mysql_query("SELECT * FROM qv_category");
  $options = '<option>No Preference</option>';
  while($category = mysql_fetch_assoc($categoryQry)) {
     $options .= '<option value="'.$category['id'].'" selected >'.$category['name'].'</option>';
  }
  return $options;
}

function deletePractitioner($practitionerID) {
	$userID = getPractitionerUserID($practitionerID);
	mysql_query("DELETE FROM qv_practitioner WHERE id='".$practitionerID."'");
	mysql_query("DELETE FROM qv_users WHERE user_id='".$userID."'");
	mysql_query("DELETE FROM qv_user_devices WHERE user_id='".$userID."'");
	return 1;
}


function companies() {

		$companyQry = mysql_query("SELECT * FROM qv_company order by created_date desc");
		$content = '';
		while($company = mysql_fetch_assoc($companyQry)) {
			if($company['status']==0){
				$status = '<button class="btn btn-success" data-toggle="modal" data-target="#blocks" type="button" id="blockcompany-'.$company['id'].'">UnBlock</button>';
			}
			else if($company['status']==1){
				$status = '<button class="btn btn-danger" data-toggle="modal" data-target="#blocks" type="button" id="blockcompany-'.$company['id'].'">Block</button>';
			}
			$date=date("Y-m-d",$company['created_date']);
		$content .= '<tr id="companyrow-'.$company['id'].'">
				<td>'.ucfirst($company['name']).'</td>
				<td>'.ucfirst($company['contact_person']).'</td>
				<td>'.$company['phone'].'</td>
				<td>'.ucfirst($company['state']).'</td>
				<td>'.$date.'</td>
				<td><a class="btn btn-warning view-company" href="company_detail.php?companyid='.$company['id'].'">View</a>
				 <a id="edit-brand" class="btn btn-info edit-company" style="margin:0 3px 0 1px;" href="edit_company.php?companyid='.$company['id'].'">Edit</a> 
				<button class="btn btn-danger delete-company" data-toggle="modal" data-target="#confirm" type="button" id="deletecompany-'.$company['id'].'">Delete</button> '.$status.'</td>
			  </tr>';		
		}
		return $content;
}

function deleteCompany($companyID) {
	$userID = getCompanyUserID($companyID);
	
	mysql_query("DELETE FROM qv_company WHERE id='".$companyID."'");
	mysql_query("DELETE FROM qv_users WHERE user_id='".$userID."'");
	mysql_query("DELETE FROM qv_user_devices WHERE user_id='".$userID."'");
	return 1;
}

function usermail()
{
    if (isset($_REQUEST['type'])) {

        if ($_REQUEST['type'] == 1) {
            $practitionerQry = mysql_query("SELECT u.user_id, p . * FROM `qv_users` u JOIN qv_practitioner p ON u.id = p.id order by`created_date` desc");
            
            if (isset($_REQUEST['catID'])) {
                
                
                if ($_REQUEST['catID'] == 1) {
                    $practitionerQry = mysql_query("SELECT u.user_id, p . * FROM `qv_users` u JOIN qv_practitioner p ON u.id = p.id WHERE category = 1 order by`created_date` desc");
                } elseif ($_REQUEST['catID'] == 2) {
                    $practitionerQry = mysql_query("SELECT u.user_id, p . * FROM `qv_users` u JOIN qv_practitioner p ON u.id = p.id WHERE category = 2 order by`created_date` desc");
                } else {
                    $practitionerQry = mysql_query("SELECT u.user_id, p . * FROM `qv_users` u JOIN qv_practitioner p ON u.id = p.id order by`created_date` desc");
                }
                
            }
            
            $content = '';
            while ($practitioner = mysql_fetch_assoc($practitionerQry)) {
                $date = date("Y-m-d", $practitioner['created_date']);
                $content .= '<tr>
                <td><input value="' . $practitioner['email'] . '" type="checkbox" name="check[]"/></td>
                <td>' . ucfirst($practitioner['firstname']) . ' ' . ucfirst($practitioner['lastname']) . '</td>
                <td>' . $practitioner['phone_no'] . '<input type="hidden" name="useid" value="' . $practitioner['user_id'] . '"></td>
                <td>' . ucfirst($practitioner['state']) . '</td>
                <td>' . $date . '</td>
              </tr>';
            }
            
            /*    return $content;*/
        } else if ($_REQUEST['type'] == 2) {
            $companyQry = mysql_query("SELECT u.user_id, c. * FROM `qv_users` u JOIN qv_company c ON u.id = c.id order by created_date desc");
            $content    = '';
            while ($company = mysql_fetch_assoc($companyQry)) {
                
                $date = date("Y-m-d", $company['created_date']);
                $content .= '<tr>
                <td><input value="' . $company['email'] . '" type="checkbox" name="check[]"/></td>
                <td>' . ucfirst($company['name']) . '</td>
                <td>' . $company['phone'] . '<input type="hidden" name="useid" value="' . $company['user_id'] . '"></td>
                <td>' . ucfirst($company['state']) . '</td>
                <td>' . $date . '</td>
              </tr>';
            }
        }
        
        else if ($_REQUEST['type'] == 0) {
            $practitionerQry = mysql_query("SELECT u.user_id, p . * FROM `qv_users` u JOIN qv_practitioner p ON u.id = p.id order by`created_date` desc");
            $content         = '';
            //$rows = array();
            while ($practitioner = mysql_fetch_assoc($practitionerQry)) {
                
                $date = date("Y-m-d", $practitioner['created_date']);
                $content .= '<tr>
                <td><input value="' . $practitioner['email'] . '" type="checkbox" name="check[]"/></td>
                <td>' . ucfirst($practitioner['firstname']) . ' ' . ucfirst($practitioner['lastname']) . '</td>
                <td>' . $practitioner['phone_no'] . '<input type="hidden" name="useid" value="' . $practitioner['user_id'] . '"></td>
                <td>' . ucfirst($practitioner['state']) . '</td>
                <td>' . $date . '</td>
              </tr>';
                
                
            }
            
            $companyQry = mysql_query("SELECT u.user_id, c. * FROM `qv_users` u JOIN qv_company c ON u.id = c.id order by created_date desc");
            $newcontent = '';
            while ($company = mysql_fetch_assoc($companyQry)) {
                
                $date = date("Y-m-d", $company['created_date']);
                $content .= '<tr>
                <td><input value="' . $company['email'] . '" type="checkbox" name="check[]"/></td>
                <td>' . ucfirst($company['name']) . '</td>
                <td>' . $company['phone'] . '<input type="hidden" name="useid" value="' . $company['user_id'] . '"></td>
                <td>' . ucfirst($company['state']) . '</td>
                <td>' . $date . '</td>
              </tr>';
                
                
            }
        }
        return $content;
    }
    
}

function appointments() {
		$requestQry = mysql_query("SELECT * FROM qv_requests");
		$content = '';
		$practitionerName ='';
	echo $practitionerName;
		while($requestData = mysql_fetch_assoc($requestQry)) {
			
			if($requestData['status']=='Completed'){
				$link ='#' ;
				$btn='btn btn-danger';
				$btntext = 'Completed';
			}
			elseif($requestData['status']=='Confirmed'){
				$link ='edit_appointment.php?appointmentid='.$requestData['id'] ;
				$btn='btn btn-primary';
				$btntext = 'Confirmed';
			}
			elseif($requestData['status']=='Accepted'){
				$link ='edit_appointment.php?appointmentid='.$requestData['id'] ;
				$btn='btn btn-info';
				$btntext = 'Accepted';
			}
			elseif($requestData['status']=='Send'){
				$link = 'edit_appointment.php?appointmentid='.$requestData['id'] ;
				$btn='btn btn-success';
				$btntext = 'Send';
			}
			elseif($requestData['status']=='Cancelled'){
				//print $requestData['status'];
				$link = '#';
				$btn='btn btn-warning';
				$btntext = 'Cancelled';
			}
			elseif($requestData['status']=='Continue'){
				$link = '#';
				if($requestData['pause_status']=='1'){
				$btn='btn btn-pause';
				$btntext = 'Paused';
				}
				else{
				$btn='btn btn-continue';
				$btntext = 'Continue';
				}
			}
			
			$companyData = getID($requestData['user_id']);
			$company = getcompanyInfo($companyData['id']);
			if($requestData['status'] == 'Accepted') {
				
				$practitioners = explode(',', $requestData['practitioner_id']);
				$practitionerIDs = array_unique($practitioners);
					//echo $practitionerName; exit;
				foreach($practitionerIDs as $ids) {
					$practitionerData = getID($ids);
					
					$practitioner = getpractitionerInfo($practitionerData['id']);
					if(empty($practitionerName)) {
						//echo "empty";
						$practitionerName = $practitioner['firstname'];
					}
					else {
					//echo "not empty";exit;
						$practitionerName = $practitionerName.', '.$practitioner['firstname'];
						
					}//echo $practitionerName;exit;
				}
				
			}
			else if($requestData['status'] == 'Send') {
				$practitionerName = '';
			}
			else {
				$practitionerData = getID($requestData['practitioner_id']);
				$practitioner = getpractitionerInfo($practitionerData['id']);
				$practitionerName = $practitioner['firstname'];
			}
			$category = getCategoryName($requestData['category']);
			if($requestData['days']!=1 &&$requestData['hours']!=1)
				$howLong = $requestData['days'].' Days '.$requestData['hours'].' Hours';
			elseif($requestData['days']==1 &&$requestData['hours']==1)
				$howLong = $requestData['days'].' Day '.$requestData['hours'].' Hour';
			elseif($requestData['days']!=1 &&$requestData['hours']==1){
				$howLong = $requestData['days'].' Days '.$requestData['hours'].' Hour';
				}
			elseif($requestData['days']==1 &&$requestData['hours']!=1){
				$howLong = $requestData['days'].' Day '.$requestData['hours'].' Hours';
				}
		$content .= '<tr id="requestrow-'.$requestData['id'].'">
				<td>'.ucfirst($company['name']).'</td>
				<td>'.ucfirst($practitionerName).'</td>
				<td>'.$category.'</td>
				<td>'.date("d/m/Y", $requestData['when']).'</td>
				<td>'.$howLong.'</td>
				<td>'.date("d/m/Y", $requestData['created_date']).'</td>
				<td><button type="button" class="'.$btn.'">'.$btntext.'</button></td>
				<td><a class="btn btn-view" href="appointment_detail.php?appointmentid='.$requestData['id'].'">View</a> 
				<a class="btn btn-edit " href="'.$link.'" >Edit</a> 
                <a class="btn btn-cancel "data-toggle="modal" data-target="#cancel" id="cancelapp-'.$requestData['id'].'" >Cancel</a> 
                <a class="btn btn-complete " data-toggle="modal" data-target="#confirm1" id="completeapp-'.$requestData['id'].'">Complete</a>
                <a class="btn btn-delete " data-toggle="modal" data-target="#confirm" id="deleteappointment-'.$requestData['id'].'">Delete</a></td>
			  </tr>';		
		}
		return $content;
}

function completeadmin($requestID) {
	//return $requestID;
	//print_r($requestID);exit;
	$requestData = mysql_fetch_assoc(mysql_query("SELECT * FROM qv_requests WHERE id='".$requestID."'"));
	$userID = $requestData['practitioner_id'];
	$totalTime = $requestData['total_service_time'];
	$extraTime = $requestData['extra_service_time'];
	//return $totalTime;
		$serviceDate = date("d/m/Y", $requestData['when']);
		$currentDate = date("d/m/Y", time());
			$checkID = mysql_query("SELECT * FROM qv_users WHERE user_id = '".$userID."' AND role_id = '3' ");
			$getID = mysql_fetch_assoc($checkID);
			$userQry = mysql_query("SELECT * from qv_practitioner WHERE id = '".$getID['id']."' ");
			$get_userInfo = mysql_fetch_assoc($userQry);
			//return $get_userInfo['hourly_rate'];
			if(!empty($totalTime)) {
				$effort = array_map('intval', explode(':', $totalTime));
				if($effort[1] == 00) {
					$cost = ($effort[0] * $get_userInfo['hourly_rate']);
				}
				else if($effort[2] == 00){
					$minutecost = ($get_userInfo['hourly_rate']/60);
					$cost = floor(($effort[0] * $get_userInfo['hourly_rate']) + ($effort[1] * $minutecost));
				}
				else {
					$minutecost = ($get_userInfo['hourly_rate']/60);
					$secondcost = ($get_userInfo['hourly_rate']/3600);
					$cost = ceil(($effort[0] * $get_userInfo['hourly_rate']) + ($effort[1] * $minutecost) + ($effort[2] * $secondcost));
				}
			}
			else {
				$cost = '0';
			}
			if($cost == '0') {
				return 3;
			}
			else {
			$transactionData = mysql_fetch_assoc(mysql_query("SELECT * FROM qv_transactions WHERE request_id ='".$requestID."'"));
			$company = getID($requestData['user_id']);
			$companyDetail = getcompanyInfo($company['id']);
			//==================If service cost exceeds authorized cost=====================
			if($cost > $transactionData['service_cost']) {
				$extraCost = ($cost - $transactionData['service_cost']);
				$capture = json_decode(payment_capture($transactionData['authorization_id'], $transactionData['service_cost']));
				$captureID = $capture->id;
				$payment = json_decode(payment_extra($requestData['user_id'], $companyDetail['name'], $extraCost));
				$paymentID = $payment->transactions[0]->related_resources[0]->sale->id;
				if(empty($captureID) || empty($paymentID)) {
					//$response['responseCode'] = 0;
					//$response['responseMessage'] = 'Something went wrong with payment processing';
					return 0;
				}
				else {
					mysql_query("UPDATE qv_transactions SET capture_id = '".$captureID."', status = 'captured', extra_transaction_id = '".$paymentID."', total_cost = '".$cost."', capture_date = '".time()."' WHERE request_id = '".$requestID."'");
					$serviceData['cost'] = $cost;
					$serviceData['verificationType'] = $requestData['verificationtype'];

					$update = mysql_query("UPDATE qv_requests SET total_service_time = '".$totalTime."', extra_service_time = '".$extraTime."', service_cost = '".$cost."', end = '".time()."', status = 'Completed' WHERE id = '".$requestID."'");
					//===================email for extra payment================================
						$to = $companyDetail['email'];
						$subject = "Extra Service Time Payment";
						$message = '<html>
<head>
<meta name=Title content="">
<meta name=Keywords content="">
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=Generator content="Microsoft Word 14 (filtered)">
<style><!--
 /* Font Definitions */
@font-face
	{font-family:"Courier New";
	panose-1:2 7 3 9 2 2 5 2 4 4;}
@font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;}
@font-face
	{font-family:"Helvetica Neue";
	panose-1:2 0 5 3 0 0 0 2 0 4;}
@font-face
	{font-family:"Helvetica Neue Light";
	panose-1:2 0 4 3 0 0 0 2 0 4;}
 /* Style Definitions */
p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:9.0pt;
	font-family:Verdana;}
h1
	{margin-top:45.0pt;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:0cm;
	font-size:30.0pt;
	font-family:Verdana;
	color:#435169;}
h2
	{margin-top:16.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:14.0pt;
	font-family:Verdana;
	color:#435169;}
h3
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:11.0pt;
	font-family:Verdana;
	color:#435169;}
p.MsoDate, li.MsoDate, div.MsoDate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
a:link, span.MsoHyperlink
	{color:blue;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{color:purple;
	text-decoration:underline;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:8.0pt;
	font-family:Tahoma;}
span.Heading1Char
	{font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.Text, li.Text, div.Text
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.Volume, li.Volume, div.Volume
	{margin:0cm;
	margin-bottom:.0001pt;
	text-align:right;
	font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	text-transform:uppercase;}
p.Subhead, li.Subhead, div.Subhead
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#435169;
	font-weight:bold;}
p.CompanyInfo, li.CompanyInfo, div.CompanyInfo
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:12.25pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-weight:bold;}
p.Quotation2Numbered, li.Quotation2Numbered, div.Quotation2Numbered
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:6.0pt;
	margin-left:32.4pt;
	text-indent:-21.6pt;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
span.Quotation2NumberedChar
	{font-family:Verdana;
	color:#506280;
	font-style:italic;}
p.TableText, li.TableText, div.TableText
	{margin:0cm;
	margin-bottom:.0001pt;
	line-height:120%;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;}
p.StyleQuotationLeft0, li.StyleQuotationLeft0, div.StyleQuotationLeft0
	{margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:0cm;
	font-size:9.0pt;
	font-family:Verdana;
	color:#506280;
	font-style:italic;}
.MsoChpDefault
	{font-size:10.0pt;}
 /* Page Definitions */
@page WordSection1
	{size:612.0pt 792.0pt;
	margin:36.0pt 36.0pt 36.7pt 36.0pt;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
--></style>
</head>
<body bgcolor="#07BEC0" lang=EN-GB link=blue vlink=purple style="tab-interval:
36.0pt">
<div class=WordSection1>
<div align=center>
<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style="border-collapse:collapse;mso-table-layout-alt:fixed;mso-yfti-tbllook:
 480;mso-padding-alt:1.45pt 18.7pt 1.45pt 12.95pt">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;height:2.55pt;mso-row-margin-right:
  .55p">
<td width=146 style="width:145.8pt;border:solid #435169 1.0pt;mso-border-alt:
  solid #435169 .5pt;mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;
  padding:1.45pt 18.7pt 1.45pt 12.95pt;height:2.55pt">
<p class=MsoNormal><span lang=EN-US style="mso-no-proof:yes"><!--[if gte vml 1]><v:shapetype
   id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t"
   path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="Picture_x0020_9" o:spid="_x0000_i1025" type="#_x0000_t75"
   alt="Description: Qova logo-22" style="width:82pt;height:73pt;visibility:visible;
   mso-wrap-style:square">
   <v:imagedata src="Qova%20email%20Template_files/image003.png" o:title="Qova logo-22"/>
  </v:shape><![endif]--><![if !vml]><img width=84 height=75 src="Qova%20email%20Template_files/image004.gif" alt="Description: Qova logo-22" v:shapes="Picture_x0020_9"><![endif]></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border:solid #435169 1.0pt;
  border-left:none;mso-border-left-alt:solid #435169 .5pt;mso-border-alt:solid #435169 .5pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:2.55pt">
<h1><span lang=EN-US style="font-size:28.0pt;color:windowtext">Temp Staff
On-Demand<span style="mso-no-proof:yes"><o:p></o:p></span></span></h1>
</td>
<td style="mso-cell-special:placeholder;border:none;border-bottom:solid #435169 1.0pt" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
<tr style="mso-yfti-irow:1;height:14.4pt">
<td width=146 style="width:145.8pt;border-top:none;border-left:solid #435169 1.0pt;
  border-bottom:solid #435169 1.0pt;border-right:none;mso-border-top-alt:solid #435169 .25pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#FFCC99;padding:1.45pt 3.6pt 1.45pt 5.75pt;
  height:14.4pt">
<p class=MsoDate><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=419 colspan=2 valign=top style="width:418.5pt;border-top:none;
  border-left:none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-top-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;mso-border-right-alt:solid #435169 .25pt;
  background:#FFCC99;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:14.4pt">
<p class=Volume><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
</tr>
<tr style="mso-yfti-irow:2;mso-yfti-lastrow:yes;height:566.65pt;mso-row-margin-right:
  .55pt">
<td width=146 valign=top style="width:145.8pt;border:solid #435169 1.0pt;
  border-top:none;mso-border-top-alt:solid #435169 .25pt;mso-border-alt:solid #435169 .25pt;
  background:#EAEDF2;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:566.65pt">
<div align=center>
<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=114 style="border-collapse:collapse;mso-table-layout-alt:fixed;border:none;
   mso-yfti-tbllook:480;mso-padding-alt:3.6pt 5.75pt 0cm 5.75pt;mso-border-insideh:
   none;mso-border-insidev:none">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes">
<td width=114 valign=top style="width:114.15pt;padding:144.0pt 5.75pt 0cm 5.75pt">
<p class=StyleQuotationLeft0><b style="mso-bidi-font-weight:normal"><span lang=EN-US style="font-size:12.0pt">3 Steps to Request Qova:<o:p></o:p></span></b></p>
</td>
</tr>
</table>
</div>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">Use the iPhone or Android app to
request Qova.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">1. View and choose your Practitioner
from the list.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">2. Sit back and relax and watch the
practitioner make their way to you.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">3. After job is completed, we will
charge your credit card on file and email you a receipt.</span></b><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue";mso-bidi-font-family:
  "Helvetica Neue""><o:p></o:p></span></p>
<p class=Quotation2Numbered style="margin-left:10.8pt;text-indent:0cm;
  mso-list:none;tab-stops:36.0pt"><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border-top:none;border-left:
  none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-alt:solid #435169 .25pt;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:566.65pt">
<h2><span lang=EN-US style="font-size:22.0pt;color:windowtext">Extra Service Time Payment<o:p></o:p></span></h2>
<h2><span lang=EN-US style="mso-bidi-font-size:14.0pt;font-family:Helvetica;
  mso-bidi-font-family:"Helvetica Neue Light";color:windowtext">Your service had exceeds to extra time. You have been charged for extra time service.</span><span lang=EN-US style="mso-bidi-font-size:14.0pt;
  font-family:Helvetica;color:windowtext"><o:p></o:p></span></h2>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt">_ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ <o:p></o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt"><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">Dear Member, <o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">Your service had exceeds to extra time. You have been charged for extra time service.<o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style="text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue"">&nbsp;</span></p>
<p class=MsoNormal style="text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue"">The extra amount charged is : '.$extraCost.'</span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:10.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626">Contact
Us</span></b><span lang=EN-US style="font-size:14.0pt;font-family:"Helvetica Neue Light";
  mso-bidi-font-family:"Helvetica Neue Light";color:#262626"><o:p></o:p></span></p>
<p class=Text><span lang=EN-US style="font-size:10.0pt;line-height:120%;
  font-family:"Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";
  color:#262626">We are here to answer any questions you may have and make sure
you have a pleasant Qova experience. To get in touch, just head to
support@qova.co.uk</span></p>
</td>
<td style="mso-cell-special:placeholder;border:none;padding:0cm 0cm 0cm 0cm" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
</table>
</div>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</div>
</body>
</html>';

						// Always set content-type when sending HTML email
						$headers = "MIME-Version: 1.0" . "\r\n";
						$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

						// More headers
						$headers .= 'From: info<info@qova.com>' . "\r\n";
						mail($to,$subject,$message,$headers);
						mysql_query("DELETE FROM qv_notifications WHERE request_id = '".$serviceID."' AND (type = 'service' OR type = 'company_response' OR type = 'practitioner_response')");
					//==========================================================================
					/*$response['responseCode'] = 200;
					$response['responseMessage'] = 'Service Completed';
					$response['serviceData'] = $serviceData;*/
					return 1;
				}
			}
			else {
				$capture = json_decode(payment_capture($transactionData['authorization_id'], $cost));
				$captureID = $capture->id;
				if(empty($captureID)) {
					// $response['responseCode'] = 0;
					// $response['responseMessage'] = 'Something went wrong with payment processing';
					return 0;
				}
				else {
					mysql_query("UPDATE qv_transactions SET capture_id = '".$captureID."', status = 'captured', total_cost = '".$cost."', capture_date = '".time()."' WHERE request_id = '".$requestID."'");
					$serviceData['cost'] = $cost;
					$serviceData['verificationType'] = $requestData['verificationtype'];

					$update = mysql_query("UPDATE qv_requests SET total_service_time = '".$totalTime."', extra_service_time = '".$extraTime."', service_cost = '".$cost."', end = '".time()."', status = 'Completed' WHERE id = '".$requestID."'");
					mysql_query("DELETE FROM qv_notifications WHERE request_id = '".$requestID."' AND (type = 'service' OR type = 'company_response' OR type = 'practitioner_response')");
					$to = $companyDetail['email'];
					$subject = "Service Payment";
					$message = '<html>
<head>
<meta name=Title content="">
<meta name=Keywords content="">
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 14">
<meta name=Originator content="Microsoft Word 14">
<link rel=File-List href="Qova%20email%20Template_files/filelist.xml">
<link rel=Edit-Time-Data href="Qova%20email%20Template_files/editdata.mso">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>Collins Chukwukere</o:Author>
  <o:Template>TM01021971</o:Template>
  <o:LastAuthor>Collins Chukwukere</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>96</o:TotalTime>
  <o:LastPrinted>2004-01-14T09:56:00Z</o:LastPrinted>
  <o:Created>2016-03-02T02:35:00Z</o:Created>
  <o:LastSaved>2016-03-02T02:35:00Z</o:LastSaved>
  <o:Pages>1</o:Pages>
  <o:Words>219</o:Words>
  <o:Characters>1254</o:Characters>
  <o:Company>Microsoft Corporation</o:Company>
  <o:Lines>10</o:Lines>
  <o:Paragraphs>2</o:Paragraphs>
  <o:CharactersWithSpaces>1471</o:CharactersWithSpaces>
  <o:Version>14.0</o:Version>
 </o:DocumentProperties>
 <o:CustomDocumentProperties>
  <o:_TemplateID dt:dt="string">TC010219711033</o:_TemplateID>
 </o:CustomDocumentProperties>
 <o:OfficeDocumentSettings>
  <o:PixelsPerInch>96</o:PixelsPerInch>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<link rel=themeData href="Qova%20email%20Template_files/themedata.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:DisplayBackgroundShape/>
  <w:SpellingState>Clean</w:SpellingState>
  <w:GrammarState>Clean</w:GrammarState>
  <w:AttachedTemplate
   HRef="Machintosh HDD:private:var:folders:d2:nlcw5ty924z9y0xcvg0xccr00000gn:T:TM01021971"></w:AttachedTemplate>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:DrawingGridHorizontalSpacing>6 pt</w:DrawingGridHorizontalSpacing>
  <w:DisplayHorizontalDrawingGridEvery>2</w:DisplayHorizontalDrawingGridEvery>
  <w:DisplayVerticalDrawingGridEvery>2</w:DisplayVerticalDrawingGridEvery>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>EN-GB</w:LidThemeOther>
  <w:LidThemeAsian>JA</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:EnableOpenTypeKerning/>
   <w:DontFlipMirrorIndents/>
   <w:OverrideTableStyleHps/>
  </w:Compatibility>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="&#45;-"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="false"
  DefSemiHidden="false" DefQFormat="false" LatentStyleCount="276">
  <w:LsdException Locked="false" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" SemiHidden="true" UnhideWhenUsed="true"
   QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" Priority="1" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" Priority="99" Name="No List"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   UnhideWhenUsed="true" Name="Note Level 1"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   UnhideWhenUsed="true" Name="Note Level 2"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   UnhideWhenUsed="true" Name="Note Level 3"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   UnhideWhenUsed="true" Name="Note Level 4"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   UnhideWhenUsed="true" Name="Note Level 5"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   UnhideWhenUsed="true" Name="Note Level 6"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   UnhideWhenUsed="true" Name="Note Level 7"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   UnhideWhenUsed="true" Name="Note Level 8"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   UnhideWhenUsed="true" Name="Note Level 9"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true"
   Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="99" SemiHidden="true" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" QFormat="true"
   Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" QFormat="true"
   Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" QFormat="true"
   Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" QFormat="true"
   Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" QFormat="true"
   Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" QFormat="true"
   Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" SemiHidden="true"
   UnhideWhenUsed="true" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" SemiHidden="true"
   UnhideWhenUsed="true" QFormat="true" Name="TOC Heading"/>
 </w:LatentStyles>
</xml><![endif]-->
<style><!--
 /* Font Definitions */
@font-face
	{font-family:"Courier New";
	panose-1:2 7 3 9 2 2 5 2 4 4;
	mso-font-charset:0;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:-536859905 -1073711037 9 0 511 0;}
@font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;
	mso-font-charset:2;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:0 268435456 0 0 -2147483648 0;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;
	mso-font-charset:0;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:-1593833729 1073750107 16 0 415 0;}
@font-face
	{font-family:Verdana;
	panose-1:2 11 6 4 3 5 4 4 2 4;
	mso-font-charset:0;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:-1593833729 1073750107 16 0 415 0;}
@font-face
	{font-family:Tahoma;
	panose-1:2 11 6 4 3 5 4 4 2 4;
	mso-font-charset:0;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:3 0 0 0 1 0;}
@font-face
	{font-family:"Helvetica Neue";
	panose-1:2 0 5 3 0 0 0 2 0 4;
	mso-font-charset:0;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:-452984065 1342208475 16 0 1 0;}
@font-face
	{font-family:"Helvetica Neue Light";
	panose-1:2 0 4 3 0 0 0 2 0 4;
	mso-font-charset:0;
	mso-generic-font-family:auto;
	mso-font-pitch:variable;
	mso-font-signature:-1610611969 1342185563 2 0 7 0;}
 /* Style Definitions */
p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:9.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	mso-ansi-language:EN-US;}
h1
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-link:"Heading 1 Char";
	mso-style-next:Normal;
	margin-top:45.0pt;
	margin-right:0cm;
	margin-bottom:10.0pt;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	mso-outline-level:1;
	font-size:30.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	color:#435169;
	mso-font-kerning:0pt;
	mso-ansi-language:EN-US;
	mso-bidi-font-weight:normal;}
h2
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:Text;
	mso-style-next:Normal;
	margin-top:16.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	mso-outline-level:2;
	font-size:14.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	color:#435169;
	mso-ansi-language:EN-US;
	mso-bidi-font-weight:normal;}
h3
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"Heading 2";
	mso-style-next:Normal;
	margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	mso-outline-level:3;
	font-size:11.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	color:#435169;
	mso-ansi-language:EN-US;
	mso-bidi-font-weight:normal;}
p.MsoDate, li.MsoDate, div.MsoDate
	{mso-style-unhide:no;
	mso-style-next:Normal;
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:8.0pt;
	font-family:Verdana;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	color:#506280;
	text-transform:uppercase;
	mso-ansi-language:EN-US;}
a:link, span.MsoHyperlink
	{mso-style-unhide:no;
	color:blue;
	mso-themecolor:hyperlink;
	text-decoration:underline;
	text-underline:single;}
a:visited, span.MsoHyperlinkFollowed
	{mso-style-unhide:no;
	color:purple;
	mso-themecolor:followedhyperlink;
	text-decoration:underline;
	text-underline:single;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{mso-style-noshow:yes;
	mso-style-unhide:no;
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:8.0pt;
	font-family:Tahoma;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:Tahoma;
	mso-ansi-language:EN-US;}
span.Heading1Char
	{mso-style-name:"Heading 1 Char";
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Heading 1";
	mso-ansi-font-size:30.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	mso-ascii-font-family:Verdana;
	mso-hansi-font-family:Verdana;
	color:#435169;
	mso-ansi-language:EN-US;
	mso-fareast-language:EN-US;
	mso-bidi-language:AR-SA;
	font-weight:bold;
	mso-bidi-font-weight:normal;}
p.Text, li.Text, div.Text
	{mso-style-name:Text;
	mso-style-unhide:no;
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:8.0pt;
	margin-left:0cm;
	line-height:120%;
	mso-pagination:widow-orphan;
	font-size:9.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	color:#506280;
	mso-ansi-language:EN-US;}
p.Volume, li.Volume, div.Volume
	{mso-style-name:Volume;
	mso-style-unhide:no;
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:right;
	mso-pagination:widow-orphan;
	font-size:8.0pt;
	font-family:Verdana;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	color:#506280;
	text-transform:uppercase;
	mso-ansi-language:EN-US;}
p.Subhead, li.Subhead, div.Subhead
	{mso-style-name:Subhead;
	mso-style-unhide:no;
	mso-style-parent:"Heading 3";
	margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:2.0pt;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	mso-outline-level:3;
	font-size:9.0pt;
	font-family:Verdana;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	color:#435169;
	mso-ansi-language:EN-US;
	font-weight:bold;
	mso-bidi-font-weight:normal;}
p.CompanyInfo, li.CompanyInfo, div.CompanyInfo
	{mso-style-name:"Company Info";
	mso-style-unhide:no;
	margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:12.25pt;
	mso-pagination:widow-orphan;
	font-size:9.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	color:#506280;
	mso-ansi-language:EN-US;
	font-weight:bold;
	mso-bidi-font-weight:normal;}
p.Quotation2Numbered, li.Quotation2Numbered, div.Quotation2Numbered
	{mso-style-name:"Quotation 2 Numbered";
	mso-style-unhide:no;
	mso-style-link:"Quotation 2 Numbered Char";
	margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:6.0pt;
	margin-left:32.4pt;
	text-indent:-21.6pt;
	mso-pagination:widow-orphan;
	mso-list:l17 level1 lfo19;
	tab-stops:list 32.4pt;
	font-size:9.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	color:#506280;
	mso-ansi-language:EN-US;
	font-style:italic;
	mso-bidi-font-style:normal;}
span.Quotation2NumberedChar
	{mso-style-name:"Quotation 2 Numbered Char";
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Quotation 2 Numbered";
	mso-ansi-font-size:9.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	mso-ascii-font-family:Verdana;
	mso-hansi-font-family:Verdana;
	color:#506280;
	mso-ansi-language:EN-US;
	mso-fareast-language:EN-US;
	mso-bidi-language:AR-SA;
	font-style:italic;
	mso-bidi-font-style:normal;}
p.TableText, li.TableText, div.TableText
	{mso-style-name:"Table Text";
	mso-style-unhide:no;
	mso-style-parent:Text;
	margin:0cm;
	margin-bottom:.0001pt;
	line-height:120%;
	mso-pagination:widow-orphan;
	font-size:9.0pt;
	mso-bidi-font-size:12.0pt;
	font-family:Verdana;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	color:#506280;
	mso-ansi-language:EN-US;}
p.StyleQuotationLeft0, li.StyleQuotationLeft0, div.StyleQuotationLeft0
	{mso-style-name:"Style Quotation + Left\:  0\0022";
	mso-style-unhide:no;
	margin-top:12.0pt;
	margin-right:0cm;
	margin-bottom:12.0pt;
	margin-left:0cm;
	mso-pagination:widow-orphan;
	font-size:9.0pt;
	mso-bidi-font-size:10.0pt;
	font-family:Verdana;
	mso-fareast-font-family:"Times New Roman";
	mso-bidi-font-family:"Times New Roman";
	color:#506280;
	mso-ansi-language:EN-US;
	font-style:italic;}
span.GramE
	{mso-style-name:"";
	mso-gram-e:yes;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	font-size:10.0pt;
	mso-ansi-font-size:10.0pt;
	mso-bidi-font-size:10.0pt;}
 /* Page Definitions */
@page
	{mso-footnote-separator:url(":Qova email Template_files:header.htm") fs;
	mso-footnote-continuation-separator:url(":Qova email Template_files:header.htm") fcs;
	mso-endnote-separator:url(":Qova email Template_files:header.htm") es;
	mso-endnote-continuation-separator:url(":Qova email Template_files:header.htm") ecs;}
@page WordSection1
	{size:612.0pt 792.0pt;
	margin:36.0pt 36.0pt 36.7pt 36.0pt;
	mso-header-margin:36.0pt;
	mso-footer-margin:36.0pt;
	mso-paper-source:0;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
@list l0
	{mso-list-id:-132;
	mso-list-type:simple;
	mso-list-template-ids:-535952250;}
@list l0:level1
	{mso-level-tab-stop:90.0pt;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;}
@list l1
	{mso-list-id:-131;
	mso-list-type:simple;
	mso-list-template-ids:834807780;}
@list l1:level1
	{mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	margin-left:72.0pt;
	text-indent:-18.0pt;}
@list l2
	{mso-list-id:-130;
	mso-list-type:simple;
	mso-list-template-ids:-493315920;}
@list l2:level1
	{mso-level-tab-stop:54.0pt;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;}
@list l3
	{mso-list-id:-129;
	mso-list-type:simple;
	mso-list-template-ids:-295272638;}
@list l4
	{mso-list-id:-128;
	mso-list-type:simple;
	mso-list-template-ids:-685977632;}
@list l4:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:90.0pt;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l5
	{mso-list-id:-127;
	mso-list-type:simple;
	mso-list-template-ids:2064304238;}
@list l5:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	margin-left:72.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l6
	{mso-list-id:-126;
	mso-list-type:simple;
	mso-list-template-ids:222732854;}
@list l6:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:54.0pt;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l7
	{mso-list-id:-125;
	mso-list-type:simple;
	mso-list-template-ids:1472114584;}
@list l7:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l8
	{mso-list-id:-120;
	mso-list-type:simple;
	mso-list-template-ids:1655889246;}
@list l8:level1
	{mso-level-tab-stop:18.0pt;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;}
@list l9
	{mso-list-id:-119;
	mso-list-type:simple;
	mso-list-template-ids:-859032622;}
@list l9:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:18.0pt;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l10
	{mso-list-id:116802324;
	mso-list-type:hybrid;
	mso-list-template-ids:899023494 1527929236 1643012350 67698715 67698703 67698713 67698715 67698703 67698713 67698715;}
@list l10:level1
	{mso-level-start-at:4;
	mso-level-tab-stop:90.0pt;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;}
@list l10:level2
	{mso-level-start-at:3;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l10:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l10:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l10:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l10:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l10:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l11
	{mso-list-id:216212517;
	mso-list-type:hybrid;
	mso-list-template-ids:-1518059252 -1850307798 67698713 67698715 67698703 67698713 67698715 67698703 67698713 67698715;}
@list l11:level1
	{mso-level-tab-stop:54.0pt;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;}
@list l11:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l11:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l11:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l11:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l11:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l11:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l12
	{mso-list-id:671571781;
	mso-list-template-ids:781079686;}
@list l12:level1
	{mso-level-number-format:image;
	list-style-image:url(":Qova email Template_files:image001.gif");
	mso-level-text:\F076;
	mso-level-tab-stop:18.0pt;
	mso-level-number-position:left;
	margin-left:18.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l12:level2
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	margin-left:36.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l12:level3
	{mso-level-number-format:image;
	list-style-image:url(":Qova email Template_files:image002.gif");
	mso-level-text:\F0A7;
	mso-level-tab-stop:54.0pt;
	mso-level-number-position:left;
	margin-left:54.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l12:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	margin-left:72.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l12:level5
	{mso-level-number-format:bullet;
	mso-level-text:\F0A8;
	mso-level-tab-stop:90.0pt;
	mso-level-number-position:left;
	margin-left:90.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l12:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0D8;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	margin-left:108.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l12:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:126.0pt;
	mso-level-number-position:left;
	margin-left:126.0pt;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l12:level8
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	margin-left:144.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l12:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A8;
	mso-level-tab-stop:162.0pt;
	mso-level-number-position:left;
	margin-left:162.0pt;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l13
	{mso-list-id:797181266;
	mso-list-type:hybrid;
	mso-list-template-ids:-1554220976 1094457546 67698691 67698693 67698689 67698691 67698693 67698689 67698691 67698693;}
@list l13:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:26.6pt;
	mso-level-number-position:left;
	margin-left:26.6pt;
	text-indent:-14.4pt;
	mso-ansi-font-size:6.0pt;
	mso-bidi-font-size:6.0pt;
	font-family:Symbol;
	color:#506280;
	mso-ansi-font-weight:normal;
	mso-ansi-font-style:normal;}
@list l13:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l13:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l13:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l13:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l13:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l13:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l13:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l13:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l14
	{mso-list-id:953092534;
	mso-list-type:hybrid;
	mso-list-template-ids:1849986740 67698703 67698713 67698715 67698703 67698713 67698715 67698703 67698713 67698715;}
@list l14:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l14:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l14:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l14:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l14:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l14:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l15
	{mso-list-id:1211502410;
	mso-list-type:hybrid;
	mso-list-template-ids:1654185516 67698703 67698713 67698715 67698703 67698713 67698715 67698703 67698713 67698715;}
@list l15:level1
	{mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	margin-left:72.0pt;
	text-indent:-18.0pt;}
@list l15:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	margin-left:108.0pt;
	text-indent:-18.0pt;}
@list l15:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:right;
	margin-left:144.0pt;
	text-indent:-9.0pt;}
@list l15:level4
	{mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	margin-left:180.0pt;
	text-indent:-18.0pt;}
@list l15:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	margin-left:216.0pt;
	text-indent:-18.0pt;}
@list l15:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:right;
	margin-left:252.0pt;
	text-indent:-9.0pt;}
@list l15:level7
	{mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	margin-left:288.0pt;
	text-indent:-18.0pt;}
@list l15:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	margin-left:324.0pt;
	text-indent:-18.0pt;}
@list l15:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:360.0pt;
	mso-level-number-position:right;
	margin-left:360.0pt;
	text-indent:-9.0pt;}
@list l16
	{mso-list-id:1316639440;
	mso-list-template-ids:317852930;}
@list l16:level1
	{mso-level-tab-stop:28.4pt;
	mso-level-number-position:left;
	margin-left:28.4pt;
	text-indent:-21.6pt;
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	mso-ansi-font-weight:normal;
	mso-ansi-font-style:italic;}
@list l16:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:91.05pt;
	mso-level-number-position:left;
	margin-left:91.05pt;
	text-indent:-18.0pt;}
@list l16:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:127.05pt;
	mso-level-number-position:right;
	margin-left:127.05pt;
	text-indent:-9.0pt;}
@list l16:level4
	{mso-level-tab-stop:163.05pt;
	mso-level-number-position:left;
	margin-left:163.05pt;
	text-indent:-18.0pt;}
@list l16:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:199.05pt;
	mso-level-number-position:left;
	margin-left:199.05pt;
	text-indent:-18.0pt;}
@list l16:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:235.05pt;
	mso-level-number-position:right;
	margin-left:235.05pt;
	text-indent:-9.0pt;}
@list l16:level7
	{mso-level-tab-stop:271.05pt;
	mso-level-number-position:left;
	margin-left:271.05pt;
	text-indent:-18.0pt;}
@list l16:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:307.05pt;
	mso-level-number-position:left;
	margin-left:307.05pt;
	text-indent:-18.0pt;}
@list l16:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:343.05pt;
	mso-level-number-position:right;
	margin-left:343.05pt;
	text-indent:-9.0pt;}
@list l17
	{mso-list-id:1517427987;
	mso-list-type:hybrid;
	mso-list-template-ids:-1212788134 1691269698 67698713 67698715 67698703 67698713 67698715 67698703 67698713 67698715;}
@list l17:level1
	{mso-level-style-link:"Quotation 2 Numbered";
	mso-level-tab-stop:32.4pt;
	mso-level-number-position:left;
	margin-left:32.4pt;
	text-indent:-21.6pt;
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	mso-ansi-font-weight:normal;
	mso-ansi-font-style:italic;}
@list l17:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:91.05pt;
	mso-level-number-position:left;
	margin-left:91.05pt;
	text-indent:-18.0pt;}
@list l17:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:127.05pt;
	mso-level-number-position:right;
	margin-left:127.05pt;
	text-indent:-9.0pt;}
@list l17:level4
	{mso-level-tab-stop:163.05pt;
	mso-level-number-position:left;
	margin-left:163.05pt;
	text-indent:-18.0pt;}
@list l17:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:199.05pt;
	mso-level-number-position:left;
	margin-left:199.05pt;
	text-indent:-18.0pt;}
@list l17:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:235.05pt;
	mso-level-number-position:right;
	margin-left:235.05pt;
	text-indent:-9.0pt;}
@list l17:level7
	{mso-level-tab-stop:271.05pt;
	mso-level-number-position:left;
	margin-left:271.05pt;
	text-indent:-18.0pt;}
@list l17:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:307.05pt;
	mso-level-number-position:left;
	margin-left:307.05pt;
	text-indent:-18.0pt;}
@list l17:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:343.05pt;
	mso-level-number-position:right;
	margin-left:343.05pt;
	text-indent:-9.0pt;}
@list l18
	{mso-list-id:1624538390;
	mso-list-type:hybrid;
	mso-list-template-ids:561924342 67698703 67698713 67698715 67698703 67698713 67698715 67698703 67698713 67698715;}
@list l18:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l18:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l18:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l18:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l18:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l18:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l19
	{mso-list-id:1788961022;
	mso-list-type:hybrid;
	mso-list-template-ids:1684864116 -1725514562 67698691 67698693 67698689 67698691 67698693 67698689 67698691 67698693;}
@list l19:level1
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l19:level2
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l19:level3
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l19:level4
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:144.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l19:level5
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l19:level6
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l19:level7
	{mso-level-number-format:bullet;
	mso-level-text:\F0B7;
	mso-level-tab-stop:252.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Symbol;}
@list l19:level8
	{mso-level-number-format:bullet;
	mso-level-text:o;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:"Courier New";}
@list l19:level9
	{mso-level-number-format:bullet;
	mso-level-text:\F0A7;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;
	font-family:Wingdings;}
@list l20
	{mso-list-id:1921208759;
	mso-list-template-ids:717882570;}
@list l20:level1
	{mso-level-tab-stop:46.05pt;
	mso-level-number-position:left;
	margin-left:46.05pt;
	text-indent:-21.6pt;
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	mso-ansi-font-weight:normal;
	mso-ansi-font-style:italic;}
@list l20:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:84.25pt;
	mso-level-number-position:left;
	margin-left:84.25pt;
	text-indent:-18.0pt;}
@list l20:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:120.25pt;
	mso-level-number-position:right;
	margin-left:120.25pt;
	text-indent:-9.0pt;}
@list l20:level4
	{mso-level-tab-stop:156.25pt;
	mso-level-number-position:left;
	margin-left:156.25pt;
	text-indent:-18.0pt;}
@list l20:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:192.25pt;
	mso-level-number-position:left;
	margin-left:192.25pt;
	text-indent:-18.0pt;}
@list l20:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:228.25pt;
	mso-level-number-position:right;
	margin-left:228.25pt;
	text-indent:-9.0pt;}
@list l20:level7
	{mso-level-tab-stop:264.25pt;
	mso-level-number-position:left;
	margin-left:264.25pt;
	text-indent:-18.0pt;}
@list l20:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:300.25pt;
	mso-level-number-position:left;
	margin-left:300.25pt;
	text-indent:-18.0pt;}
@list l20:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:336.25pt;
	mso-level-number-position:right;
	margin-left:336.25pt;
	text-indent:-9.0pt;}
@list l21
	{mso-list-id:1927953567;
	mso-list-type:hybrid;
	mso-list-template-ids:-729896934 -75723592 67698713 67698715 67698703 67698713 67698715 67698703 67698713 67698715;}
@list l21:level1
	{mso-level-tab-stop:33.8pt;
	mso-level-number-position:left;
	margin-left:33.8pt;
	text-indent:-21.6pt;
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	mso-ansi-font-weight:normal;
	mso-ansi-font-style:italic;}
@list l21:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:72.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l21:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:108.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l21:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:180.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l21:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:216.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l21:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:288.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
@list l21:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:324.0pt;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l22
	{mso-list-id:2035377944;
	mso-list-template-ids:424850226;}
@list l22:level1
	{mso-level-tab-stop:32.4pt;
	mso-level-number-position:left;
	margin-left:32.4pt;
	text-indent:-21.6pt;
	mso-ansi-font-size:8.0pt;
	mso-bidi-font-size:8.0pt;
	font-family:Verdana;
	color:#506280;
	mso-ansi-font-weight:normal;
	mso-ansi-font-style:italic;}
@list l22:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:91.05pt;
	mso-level-number-position:left;
	margin-left:91.05pt;
	text-indent:-18.0pt;}
@list l22:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:127.05pt;
	mso-level-number-position:right;
	margin-left:127.05pt;
	text-indent:-9.0pt;}
@list l22:level4
	{mso-level-tab-stop:163.05pt;
	mso-level-number-position:left;
	margin-left:163.05pt;
	text-indent:-18.0pt;}
@list l22:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:199.05pt;
	mso-level-number-position:left;
	margin-left:199.05pt;
	text-indent:-18.0pt;}
@list l22:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:235.05pt;
	mso-level-number-position:right;
	margin-left:235.05pt;
	text-indent:-9.0pt;}
@list l22:level7
	{mso-level-tab-stop:271.05pt;
	mso-level-number-position:left;
	margin-left:271.05pt;
	text-indent:-18.0pt;}
@list l22:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:307.05pt;
	mso-level-number-position:left;
	margin-left:307.05pt;
	text-indent:-18.0pt;}
@list l22:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:343.05pt;
	mso-level-number-position:right;
	margin-left:343.05pt;
	text-indent:-9.0pt;}
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
--></style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman";}
table.MsoTableGrid
	{mso-style-name:"Table Grid";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-unhide:no;
	border:solid windowtext 1.0pt;
	mso-border-alt:solid windowtext .5pt;
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-border-insideh:.5pt solid windowtext;
	mso-border-insidev:.5pt solid windowtext;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:10.0pt;
	font-family:"Times New Roman";}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="2049">
  <o:colormru v:ext="edit" colors="#07bec0"/>
 </o:shapedefaults></xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>
<body bgcolor="#07BEC0" lang=EN-GB link=blue vlink=purple style="tab-interval:
36.0pt">
<div class=WordSection1>
<div align=center>
<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style="border-collapse:collapse;mso-table-layout-alt:fixed;mso-yfti-tbllook:
 480;mso-padding-alt:1.45pt 18.7pt 1.45pt 12.95pt">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;height:2.55pt;mso-row-margin-right:
  .55p">
<td width=146 style="width:145.8pt;border:solid #435169 1.0pt;mso-border-alt:
  solid #435169 .5pt;mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;
  padding:1.45pt 18.7pt 1.45pt 12.95pt;height:2.55pt">
<p class=MsoNormal><span lang=EN-US style="mso-no-proof:yes"><!--[if gte vml 1]><v:shapetype
   id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t"
   path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f">
   <v:stroke joinstyle="miter"/>
   <v:formulas>
    <v:f eqn="if lineDrawn pixelLineWidth 0"/>
    <v:f eqn="sum @0 1 0"/>
    <v:f eqn="sum 0 0 @1"/>
    <v:f eqn="prod @2 1 2"/>
    <v:f eqn="prod @3 21600 pixelWidth"/>
    <v:f eqn="prod @3 21600 pixelHeight"/>
    <v:f eqn="sum @0 0 1"/>
    <v:f eqn="prod @6 1 2"/>
    <v:f eqn="prod @7 21600 pixelWidth"/>
    <v:f eqn="sum @8 21600 0"/>
    <v:f eqn="prod @7 21600 pixelHeight"/>
    <v:f eqn="sum @10 21600 0"/>
   </v:formulas>
   <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
   <o:lock v:ext="edit" aspectratio="t"/>
  </v:shapetype><v:shape id="Picture_x0020_9" o:spid="_x0000_i1025" type="#_x0000_t75"
   alt="Description: Qova logo-22" style="width:82pt;height:73pt;visibility:visible;
   mso-wrap-style:square">
   <v:imagedata src="Qova%20email%20Template_files/image003.png" o:title="Qova logo-22"/>
  </v:shape><![endif]--><![if !vml]><img width=84 height=75 src="Qova%20email%20Template_files/image004.gif" alt="Description: Qova logo-22" v:shapes="Picture_x0020_9"><![endif]></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border:solid #435169 1.0pt;
  border-left:none;mso-border-left-alt:solid #435169 .5pt;mso-border-alt:solid #435169 .5pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#CED5E0;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:2.55pt">
<h1><span lang=EN-US style="font-size:28.0pt;color:windowtext">Temp Staff
On-Demand<span style="mso-no-proof:yes"><o:p></o:p></span></span></h1>
</td>
<td style="mso-cell-special:placeholder;border:none;border-bottom:solid #435169 1.0pt" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
<tr style="mso-yfti-irow:1;height:14.4pt">
<td width=146 style="width:145.8pt;border-top:none;border-left:solid #435169 1.0pt;
  border-bottom:solid #435169 1.0pt;border-right:none;mso-border-top-alt:solid #435169 .25pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;background:#FFCC99;padding:1.45pt 3.6pt 1.45pt 5.75pt;
  height:14.4pt">
<p class=MsoDate><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=419 colspan=2 valign=top style="width:418.5pt;border-top:none;
  border-left:none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-top-alt:solid #435169 .25pt;
  mso-border-bottom-alt:solid #435169 .25pt;mso-border-right-alt:solid #435169 .25pt;
  background:#FFCC99;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:14.4pt">
<p class=Volume><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
</tr>
<tr style="mso-yfti-irow:2;mso-yfti-lastrow:yes;height:566.65pt;mso-row-margin-right:
  .55pt">
<td width=146 valign=top style="width:145.8pt;border:solid #435169 1.0pt;
  border-top:none;mso-border-top-alt:solid #435169 .25pt;mso-border-alt:solid #435169 .25pt;
  background:#EAEDF2;padding:1.45pt 18.7pt 1.45pt 12.95pt;height:566.65pt">
<div align=center>
<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=114 style="border-collapse:collapse;mso-table-layout-alt:fixed;border:none;
   mso-yfti-tbllook:480;mso-padding-alt:3.6pt 5.75pt 0cm 5.75pt;mso-border-insideh:
   none;mso-border-insidev:none">
<tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes">
<td width=114 valign=top style="width:114.15pt;padding:144.0pt 5.75pt 0cm 5.75pt">
<p class=StyleQuotationLeft0><b style="mso-bidi-font-weight:normal"><span lang=EN-US style="font-size:12.0pt">3 Steps to Request Qova:<o:p></o:p></span></b></p>
</td>
</tr>
</table>
</div>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">Use the iPhone or Android app to
request Qova.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">1. View and choose your Practitioner
from the list.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">2. Sit back and relax and watch the
practitioner make their way to you.<o:p></o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="margin-bottom:12.0pt;line-height:16.0pt;mso-pagination:
  none;mso-layout-grid-align:none;text-autospace:none"><b style="mso-bidi-font-weight:
  normal"><span lang=EN-US style="font-size:10.0pt;font-family:"Helvetica Neue";
  mso-bidi-font-family:"Helvetica Neue"">3. After job is completed, we will
charge your credit card on file and email you a receipt.</span></b><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue";mso-bidi-font-family:
  "Helvetica Neue""><o:p></o:p></span></p>
<p class=Quotation2Numbered style="margin-left:10.8pt;text-indent:0cm;
  mso-list:none;tab-stops:36.0pt"><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</td>
<td width=418 valign=top style="width:417.95pt;border-top:none;border-left:
  none;border-bottom:solid #435169 1.0pt;border-right:solid #435169 1.0pt;
  mso-border-top-alt:solid #435169 .25pt;mso-border-left-alt:solid #435169 .25pt;
  mso-border-alt:solid #435169 .25pt;padding:1.45pt 18.7pt 1.45pt 12.95pt;
  height:566.65pt">
<h2><span lang=EN-US style="font-size:22.0pt;color:windowtext">Service Payment<o:p></o:p></span></h2>
<h2><span lang=EN-US style="mso-bidi-font-size:14.0pt;font-family:Helvetica;
  mso-bidi-font-family:"Helvetica Neue Light";color:windowtext">Your service has been completed. You have been charged for it.</span><span lang=EN-US style="mso-bidi-font-size:14.0pt;
  font-family:Helvetica;color:windowtext"><o:p></o:p></span></h2>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt">_ _ _ _ _ _ _ _
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ <o:p></o:p></span></p>
<p class=MsoNormal><span lang=EN-US style="font-size:10.0pt"><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">Dear Member, <o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue"">Your service has been completed. You have been charged for your services. The amount deducted for the service is mentioned below.<o:p></o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style="text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue"">&nbsp;</span></p>
<p class=MsoNormal style="text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:"Helvetica Neue"">The amount charged is : '.$cost.'</span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><span lang=EN-US style="font-size:12.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue""><o:p>&nbsp;</o:p></span></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:10.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626"><o:p>&nbsp;</o:p></span></b></p>
<p class=MsoNormal style="mso-pagination:none;mso-layout-grid-align:none;
  text-autospace:none"><b><span lang=EN-US style="font-size:14.0pt;font-family:
  "Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";color:#262626">Contact
Us</span></b><span lang=EN-US style="font-size:14.0pt;font-family:"Helvetica Neue Light";
  mso-bidi-font-family:"Helvetica Neue Light";color:#262626"><o:p></o:p></span></p>
<p class=Text><span lang=EN-US style="font-size:10.0pt;line-height:120%;
  font-family:"Helvetica Neue";mso-bidi-font-family:"Helvetica Neue";
  color:#262626">We are here to answer any questions you may have and make sure
you have a pleasant Qova experience. To get in touch, just head to
support@qova.co.uk</span></p>
</td>
<td style="mso-cell-special:placeholder;border:none;padding:0cm 0cm 0cm 0cm" width=1><p class="MsoNormal">&nbsp;</td>
</tr>
</table>
</div>
<p class=MsoNormal><span lang=EN-US><o:p>&nbsp;</o:p></span></p>
</div>
</body>
</html>';

						// Always set content-type when sending HTML email
						$headers = "MIME-Version: 1.0" . "\r\n";
						$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

						// More headers
						$headers .= 'From: info<info@qova.com>' . "\r\n";
						mail($to,$subject,$message,$headers);

					/*$response['responseCode'] = 200;
					$response['responseMessage'] = 'Service Completed';
					$response['serviceData'] = $serviceData;*/
					return 1;
				}
			}
		}
	return 1;
	
}





/*function transfer_payment($practitionerID) {
	
	$captured=mysql_fetch_assoc(mysql_query("SELECT sum(total_cost) as total FROM qv_transactions WHERE transfer_status='0' AND status = 'captured' AND practitioner_id = '".$practitionerID."' group by practitioner_id"));
	$practionerID=mysql_fetch_assoc(mysql_query("SELECT id FROM `qv_users` WHERE role_id=3 and user_id='".$practitionerID."'"));
	$practitionerInfo=getpractitionerInfo($practionerID['id']);
	// eMail subject to receivers
$vEmailSubject = 'Qova';
$environment = 'sandbox'; // or 'beta-sandbox' or 'live'.

function PPHttpPost($methodName_, $nvpStr_)
{
	global $environment;

	$API_UserName = urlencode('prashant.dwivedi-facilitator_api1.mobiloitte.com');
	$API_Password = urlencode('965ZNT59L9JKEZ5N');
	$API_Signature = urlencode('AiPC9BjkCyDFQXbSkoZcgqH3hpacAv24ACqokwcC-LOvDidqgZgRZ8rS');
	$API_Endpoint = "https://api-3t.paypal.com/nvp";
	if("sandbox" === $environment || "beta-sandbox" === $environment)
	{
		$API_Endpoint = "https://api-3t.$environment.paypal.com/nvp";
	} 
	$version = urlencode('51.0');
	// Set the curl parameters.
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $API_Endpoint);
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	// Turn off the server and peer verification (TrustManager Concept).
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	// Set the API operation, version, and API signature in the request.
	$nvpreq = "METHOD=$methodName_&VERSION=$version&PWD=$API_Password&USER=$API_UserName&SIGNATURE=$API_Signature$nvpStr_";
	// Set the request as a POST FIELD for curl.
	curl_setopt($ch, CURLOPT_POSTFIELDS, $nvpreq."&".$nvpStr_);
	// Get response from the server.
	$httpResponse = curl_exec($ch);
	if(!$httpResponse)
	{
		echo $methodName_ . ' failed: ' . curl_error($ch) . '(' . curl_errno($ch) .')';
	}
	// Extract the response details.
	$httpResponseAr = explode("&", $httpResponse);
	$httpParsedResponseAr = array();
	foreach ($httpResponseAr as $i => $value)
	{
		$tmpAr = explode("=", $value);
		if(sizeof($tmpAr) > 1)
		{
			$httpParsedResponseAr[$tmpAr[0]] = $tmpAr[1];
		}
	}
	if((0 == sizeof($httpParsedResponseAr)) || !array_key_exists('ACK', $httpParsedResponseAr))
	{
		exit("Invalid HTTP Response for POST request($nvpreq) to $API_Endpoint.");
	}
	//print'<pre>';print_r($httpParsedResponseAr);
	return $httpParsedResponseAr;
}

	// Set request-specific fields.
	$emailSubject = urlencode($vEmailSubject);
	$receiverType = urlencode('EmailAddress');
	$currency = urlencode('GBP'); // or other currency ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')
	// Receivers
	// Use '0' for a single receiver. In order to add new ones: (0, 1, 2, 3...)
	// Here you can modify to obtain array data from database.
	$receivers = array(
		0 => array(
			'receiverEmail' => $practitionerInfo['paypal_id'], 
			'amount' => $captured['total'],
			'uniqueID' => "id_001", // 13 chars max
			'note' => " Qova"), // I recommend use of space at beginning of string.
	);
	//return json_encode($receivers);
	$receiversLenght = count($receivers);

	// Add request-specific fields to the request string.
	$nvpStr="&EMAILSUBJECT=$emailSubject&RECEIVERTYPE=$receiverType&CURRENCYCODE=$currency";
	$receiversArray = array();
	for($i = 0; $i < $receiversLenght; $i++)
	{
		$receiversArray[$i] = $receivers[$i];
	}
	foreach($receiversArray as $i => $receiverData)
	{
		$receiverEmail = urlencode($receiverData['receiverEmail']);
		$amount = urlencode($receiverData['amount']);
		$uniqueID = urlencode($receiverData['uniqueID']);
		$note = urlencode($receiverData['note']);
		$nvpStr .= "&L_EMAIL$i=$receiverEmail&L_Amt$i=$amount&L_UNIQUEID$i=$uniqueID&L_NOTE$i=$note";
	}
	// Execute the API operation; see the PPHttpPost function above.
	$httpParsedResponseAr = PPHttpPost('MassPay', $nvpStr);

	if("SUCCESS" == strtoupper($httpParsedResponseAr["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($httpParsedResponseAr["ACK"]))
	{
		mysql_query("UPDATE qv_transactions SET transfer_status = 1 AND transfer_date = '".time()."' WHERE transfer_status='0' AND status = 'captured' AND practitioner_id = '".$practitionerID."'");
		return json_encode($httpParsedResponseAr);
	}
	else
	{
		return json_encode($httpParsedResponseAr);
	}
} */

?>
